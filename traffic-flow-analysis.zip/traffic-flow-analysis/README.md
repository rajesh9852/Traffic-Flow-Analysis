
# Traffic Flow Analysis (YOLOv8 + DeepSORT)

Counts vehicles per lane in a traffic video, with tracking to avoid double-counting.  
Tested with the sample video: https://www.youtube.com/watch?v=MNn9qKG2UFI

## Features
- **Vehicle detection** using Ultralytics YOLOv8 (COCO pre-trained).
- **Tracking** with DeepSORT for persistent IDs.
- **Three lane** polygons and **per-lane counting**.
- **CSV log** with `vehicle_id, lane, frame, timestamp`.
- **Annotated video** overlay with lane regions and live counters.
- Real-time or near real-time on standard hardware (use `yolov8n.pt`).

## Setup

```bash
# 1) Create and activate a virtual environment (recommended)
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# 2) Install dependencies
pip install -r requirements.txt
```

> If you encounter issues building `lapx`, install build tools first. On Windows, install *Build Tools for Visual Studio*; on Ubuntu/Debian: `sudo apt-get install build-essential python3-dev`.

## Run

### Quick demo (1 minute of the YouTube video)
```bash
python main.py --save --csv --max-seconds 60
```

### Full processing
```bash
python main.py --save --csv
```

### Use a local video file and show live window
```bash
python main.py --source path/to/video.mp4 --skip-download --show --save --csv
```

### Choose classes (default: car, truck, bus, motorbike)
```bash
python main.py --classes car truck bus motorbike
```

Outputs are written to `./output/`:
- `annotated.mp4` — overlay video with bounding boxes, lane polygons, and live counts.
- `events.csv` — CSV with columns: Vehicle ID, Lane, Frame, Timestamp.
- `summary.txt` — total count per lane at the end.

## Lane Configuration

By default, the script splits the **lower half** of the frame into **three vertical lanes**.  
To customize lanes:
1. Open `main.py` and edit `make_lane_polygons(w, h)`. Provide three polygons as lists of `(x, y)` points.
2. Use OpenCV coordinates (origin at top-left). You can visualize by running with `--show` and adjusting.

Example snippet to make diagonal lanes:
```python
def make_lane_polygons(w, h):
    lane1 = np.array([[int(0.05*w), h-1], [int(0.20*w), int(0.4*h)], [int(0.33*w), int(0.4*h)], [int(0.18*w), h-1]], dtype=np.int32)
    lane2 = np.array([[int(0.34*w), h-1], [int(0.44*w), int(0.4*h)], [int(0.57*w), int(0.4*h)], [int(0.47*w), h-1]], dtype=np.int32)
    lane3 = np.array([[int(0.58*w), h-1], [int(0.68*w), int(0.4*h)], [int(0.95*w), int(0.4*h)], [int(0.75*w), h-1]], dtype=np.int32)
    return [lane1, lane2, lane3]
```

## How it works

1. **Detection**: YOLOv8 runs per frame; we filter to vehicle classes.
2. **Tracking**: DeepSORT ingests detections (bbox, confidence, class) and returns stable track IDs.
3. **Lane assignment**: For each confirmed track, compute centroid and test if it lies inside one of the lane polygons.
4. **Counting**: Each `(track_id, lane)` pair is counted **once** (when it first appears inside that lane). IDs are stored to prevent duplicates.
5. **Timestamp**: Computed as `frame_index / fps` and formatted as `HH:MM:SS.microseconds`.

## Tips for performance
- Use `yolov8n.pt` or `yolov8s.pt` for speed; switch to GPU by `--device 0` if available.
- Reduce `--conf` (e.g., 0.25) or limit classes to speed up.
- Use `--max-seconds` during development for faster iteration.

## Technical Notes
- **Dependencies**: `ultralytics` for YOLO, `deep-sort-realtime` for tracker, `yt-dlp` for YouTube download, `opencv-python` for video I/O.
- We use centroid-in-polygon with `cv2.pointPolygonTest` to assign lanes.
- Counting on first entry avoids duplicate counts across frames.

## File Tree
```
traffic-flow-analysis/
├─ main.py
├─ requirements.txt
├─ README.md
└─ output/
```

## Deliverables Checklist
- [x] Python script (`main.py`)
- [x] README with setup & usage
- [x] CSV + annotated video generated on run
- [x] (Optional) Record a 1–2 min screen capture of the running app for your demo video
- [x] Ready to push to GitHub

## License
MIT
