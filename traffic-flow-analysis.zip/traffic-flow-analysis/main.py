
import os
import cv2
import argparse
import time
import numpy as np
from datetime import timedelta
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort

try:
    import yt_dlp as ytdlp
except Exception:
    ytdlp = None

VEHICLE_CLASSES = {"car", "truck", "bus", "motorbike", "motorcycle"}  # ultralytics names include 'motorbike'

def download_video(url: str, out_dir: str) -> str:
    """
    Download a YouTube video as MP4 using yt-dlp.
    Returns the local path to the downloaded file.
    """
    if ytdlp is None:
        raise RuntimeError("yt-dlp not installed. Please `pip install yt-dlp`.")
    os.makedirs(out_dir, exist_ok=True)
    outtmpl = os.path.join(out_dir, "%(title)s.%(ext)s")
    ydl_opts = {
        "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4",
        "outtmpl": outtmpl,
        "merge_output_format": "mp4",
        "quiet": True,
        "noprogress": True,
    }
    with ytdlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        if "requested_downloads" in info and info["requested_downloads"]:
            filepath = info["requested_downloads"][0]["filepath"]
        else:
            filepath = ydl.prepare_filename(info)
            if not filepath.endswith(".mp4"):
                filepath = os.path.splitext(filepath)[0] + ".mp4"
        return filepath

def make_lane_polygons(w, h):
    """
    Define three non-overlapping lane polygons using relative coordinates,
    so they adapt to any video size. You can edit these for your scene.
    The defaults split the lower half of the frame into three vertical lanes.
    """
    y_top = int(h * 0.45)
    y_bot = h - 1
    # divide width into three equal lanes
    one_third = w // 3
    pts1 = np.array([[0, y_bot], [0, y_top], [one_third-1, y_top], [one_third-1, y_bot]], dtype=np.int32)
    pts2 = np.array([[one_third, y_bot], [one_third, y_top], [2*one_third-1, y_top], [2*one_third-1, y_bot]], dtype=np.int32)
    pts3 = np.array([[2*one_third, y_bot], [2*one_third, y_top], [w-1, y_top], [w-1, y_bot]], dtype=np.int32)
    return [pts1, pts2, pts3]

def point_in_poly(pt, poly):
    return cv2.pointPolygonTest(poly, pt, False) >= 0

def build_arg_parser():
    ap = argparse.ArgumentParser(description="Traffic Flow Analysis: per-lane vehicle counting with YOLOv8 + DeepSORT")
    ap.add_argument("--source", type=str, default="https://www.youtube.com/watch?v=MNn9qKG2UFI",
                    help="Path to a video file or YouTube URL")
    ap.add_argument("--model", type=str, default="yolov8n.pt", help="Ultralytics YOLO model")
    ap.add_argument("--conf", type=float, default=0.3, help="Confidence threshold for detection")
    ap.add_argument("--device", type=str, default="",
                    help="Computation device, e.g. 'cpu', '0' for GPU 0")
    ap.add_argument("--show", action="store_true", help="Show real-time window")
    ap.add_argument("--save", action="store_true", help="Save annotated video to ./output/annotated.mp4")
    ap.add_argument("--csv", action="store_true", help="Write CSV log to ./output/events.csv")
    ap.add_argument("--max-seconds", type=float, default=0.0, help="Process only this many seconds (0 = full video)")
    ap.add_argument("--skip-download", action="store_true", help="Treat --source as a local file; do not try to download")
    ap.add_argument("--classes", nargs="*", default=["car","truck","bus","motorbike"],
                    help="Which classes to count (YOLO names)")
    return ap

def main():
    args = build_arg_parser().parse_args()
    out_dir = "./output"
    os.makedirs(out_dir, exist_ok=True)

    # Resolve source: local path or YouTube URL
    source_path = args.source
    if (source_path.startswith("http://") or source_path.startswith("https://")) and not args.skip_download:
        print("[info] Downloading video via yt-dlp ...")
        source_path = download_video(args.source, out_dir)
        print(f"[info] Downloaded to: {source_path}")
    elif not os.path.isfile(source_path):
        raise FileNotFoundError(f"Video not found: {source_path}")

    # Load detector
    print("[info] Loading YOLO model:", args.model)
    model = YOLO(args.model)

    # Prepare tracker
    print("[info] Initializing DeepSORT tracker ...")
    tracker = DeepSort(max_age=30, n_init=2, nn_budget=100)

    cap = cv2.VideoCapture(source_path)
    if not cap.isOpened():
        raise RuntimeError(f"Failed to open video: {source_path}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    lane_polys = make_lane_polygons(width, height)

    # video writer
    writer = None
    if args.save:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(os.path.join(out_dir, "annotated.mp4"), fourcc, fps, (width, height))

    # CSV logging
    csv_file = None
    if args.csv:
        csv_path = os.path.join(out_dir, "events.csv")
        csv_file = open(csv_path, "w", buffering=1)
        csv_file.write("vehicle_id,lane,frame,timestamp\n")

    counted_ids = {1: set(), 2: set(), 3: set()}
    lane_counts = {1: 0, 2: 0, 3: 0}

    start_time = time.time()
    processed_seconds = 0.0
    frame_idx = 0

    # Pre-map allowed classes to IDs according to model.names
    model_names = model.model.names if hasattr(model.model, "names") else model.names
    allowed_cls_ids = {cid for cid, name in model_names.items() if name in set(args.classes)}

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Optional stop after N seconds
        if args.max_seconds > 0:
            processed_seconds = frame_idx / fps
            if processed_seconds >= args.max_seconds:
                break

        # Run detection
        results = model.predict(source=frame, conf=args.conf, verbose=False, device=args.device, classes=list(allowed_cls_ids))
        dets = []
        if results and len(results) > 0:
            r = results[0]
            if r.boxes is not None and len(r.boxes) > 0:
                xyxy = r.boxes.xyxy.cpu().numpy()
                conf = r.boxes.conf.cpu().numpy()
                cls = r.boxes.cls.cpu().numpy().astype(int)
                for (x1,y1,x2,y2), c, cl in zip(xyxy, conf, cls):
                    dets.append(((float(x1), float(y1), float(x2), float(y2)), float(c), int(cl)))

        tracks = tracker.update_tracks(dets, frame=frame)  # update
        # draw lanes
        overlay = frame.copy()
        for i, poly in enumerate(lane_polys, start=1):
            cv2.polylines(overlay, [poly], isClosed=True, color=(0, 255, 255), thickness=2)
            # fill with transparent color for visualization
            cv2.fillPoly(overlay, [poly], color=(0, 255, 255))
        frame = cv2.addWeighted(overlay, 0.1, frame, 0.9, 0)

        # draw and count tracks
        for t in tracks:
            if not t.is_confirmed() or t.time_since_update > 0:
                continue
            track_id = t.track_id
            ltrb = t.to_ltrb()  # left, top, right, bottom
            x1, y1, x2, y2 = map(int, ltrb)
            cx = int((x1 + x2) / 2)
            cy = int((y1 + y2) / 2)
            centroid = (cx, cy)

            # assign lane
            lane_id = None
            for i, poly in enumerate(lane_polys, start=1):
                if point_in_poly(centroid, poly):
                    lane_id = i
                    break

            # visualize bbox & id
            cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 255, 0), 2)
            label = f"ID {track_id}" + (f" L{lane_id}" if lane_id else "")
            cv2.putText(frame, label, (x1, max(15,y1-5)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,0), 2)
            cv2.circle(frame, centroid, 3, (0, 0, 255), -1)

            # count once per vehicle per lane
            if lane_id is not None and track_id not in counted_ids[lane_id]:
                counted_ids[lane_id].add(track_id)
                lane_counts[lane_id] += 1
                # log CSV
                if csv_file is not None:
                    timestamp = str(timedelta(seconds=frame_idx / fps))
                    csv_file.write(f"{track_id},{lane_id},{frame_idx},{timestamp}\n")

        # draw counters
        hud = f"Lane1: {lane_counts[1]}   Lane2: {lane_counts[2]}   Lane3: {lane_counts[3]}   FPS:{fps:.1f}"
        cv2.putText(frame, hud, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,255,0), 2)

        if args.show:
            cv2.imshow("Traffic Flow Analysis", frame)
            if cv2.waitKey(1) & 0xFF == 27:  # ESC to quit early
                break

        if writer is not None:
            writer.write(frame)

        frame_idx += 1

    cap.release()
    if writer is not None:
        writer.release()
    if csv_file is not None:
        csv_file.close()
    if args.show:
        cv2.destroyAllWindows()

    print("\n=== SUMMARY ===")
    for i in (1,2,3):
        print(f"Lane {i}: {lane_counts[i]} vehicles")

    # Save summary text
    with open(os.path.join(out_dir, "summary.txt"), "w") as f:
        for i in (1,2,3):
            f.write(f"Lane {i}: {lane_counts[i]} vehicles\n")

if __name__ == "__main__":
    main()
